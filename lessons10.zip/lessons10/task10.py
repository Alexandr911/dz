from prettytable import PrettyTable

if __name__ == '__main__':

    class HomeLibrary(object):

        def __init__(self,
                     avtor='',
                     name='',
                     genre='',
                     year=None):
            self.avtor = avtor
            self.name = name
            self.genre = genre
            self.year = year


        def __str__(self):
            return str(self.__dict__)


    books = [HomeLibrary(b[0], b[1], b[2], b[3]) for b in [
        ("Джордж Р. Р. Мартин", "Игра престолов", "Фантастика Язык", 2015),
        ("Роберто Савиано", "Пираньи Неаполя", "Трелер", 2019),
        ("Маргарет Митчелл", "Унесенные ветром", "Художественная", 1991),
        ("Андрей Круз", "Я еду домой!", "Фантастический боевик", 2009),
        ("Артур Хейли", "Аэропорт", "Эксклюзивная классика", 2004)
    ]]

    print("All Books:")
    for b in books:
        print(b)


    def select_by_year(books, year):
        for b in books:
            if b.year == year:
                yield b

    print("Books in 2019:")
    for b in select_by_year(books, 2019):
        print(b)

    print("Books of Artyr:")
    for b in [b for b in books if "Артур" in b.avtor]:
        print(b)

    print("Sorted books by Name:")
    for b in sorted(books, key=lambda b: b.name):
        print(b)

    book = PrettyTable(["Автор", "Книга", "Жарн", "Год"])
    book.add_row(["Роберто Савиано", "Пираньи Неаполя", "Трелер", 2019])
    book.add_row(["Джордж Р. Р. Мартин", "Игра престолов", "Фантастика Язык", 2015])
    book.add_row(["Андрей Круз", "Я еду домой!", "Фантастический боевик", 2009])
    book.add_row(["Артур Хейли", "Аэропорт", "Эксклюзивная классика", 2004])
    book.add_row(["Маргарет Митчелл", "Унесенные ветром", "Художественная", 1991])
    book.reversesort = True
    print(book)

    print("Table sorted by Name:")
    book.sortby = "Книга"
    print(book)