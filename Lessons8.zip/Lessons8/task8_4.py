

def generate_num(numb, leng):
    for i in range(leng):
        triangle = (numb*(numb+1)) / 2
        print(triangle)
        numb += 1


if __name__ == '__main__':
    generate_num(1, 390)