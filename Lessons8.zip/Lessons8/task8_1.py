from time import time, sleep

def execution_time(f):
    def _wrap(*args, **kwargs):
        start_execution = time()
        result = f(*args, **kwargs)
        print("Time of execution:", time() - start_execution)
        return result
    return _wrap


@execution_time
def execute():
    sleep(5)

if __name__ == '__main__':
    print('* ' * 40)
    print('Tasks №1')
    print('Написать декоратор который будет выводить на экран время выполнения функции')
    print('Ждем....')
    execute()

