

def generate_list(length):
    lst = []
    i = 0
    while len(lst) < length:
        if i % 3 == 0:
            lst.append(i)
        i += 1
    lst.sort(reverse=True)
    return lst

# @generate_list
# def input_(lenght):
#     input_data = input(length)
#     if not input_data.isdigit(): return input_("Вы ввели не число! Введите число: ")
#     if 10 <= int(input_data) <= 50: return input_data
#     return input_("Ваше число не диапазоне! Введите число:")
# print(input_("Введите число: "))


if __name__ == "__main__":
    print('Tasks №2')
    while True:
        length = input('Введите число ')
        try:
            length = int(length)
            break
        except:
            if length.isalpha():
                print("Введены буквы")
            else:
                print("Введены непонятные символа")
    result = generate_list(length)
    print(result)

    print(generate_list(4))
    # print(generate_list(10))